//Here we are creating  a constructor to get the excelpath and sheetName

package Utils;

import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils_two {
	static XSSFWorkbook wb;
	static XSSFSheet sheet;

	public  ExcelUtils_two(String exlPath, String shtName)
	{
		try
		{
			 wb= new XSSFWorkbook(exlPath);
			sheet= wb.getSheet(shtName);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}
		
		
	}
	
	
	public static void getCelData(int rNum, int colNum)
	{
		
			DataFormatter frmatter= new DataFormatter();
			Object value= frmatter.formatCellValue(sheet.getRow(rNum).getCell(colNum));
			System.out.println( value);
			
	}
	
	public static void getRowCount()
	{
			int rowCount= sheet.getPhysicalNumberOfRows();
			System.out.println("No of rows including the HEAD LINE : "+rowCount);		
		
	}
}
