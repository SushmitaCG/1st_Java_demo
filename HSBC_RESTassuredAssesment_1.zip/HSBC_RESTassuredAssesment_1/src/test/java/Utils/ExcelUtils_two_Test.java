package Utils;

public class ExcelUtils_two_Test {
	
	public static void main(String args[])
	{
		
		String exlPath="./DATA/Test.xlsx";
		String shtName="Sheet1";
		ExcelUtils_two xl= new ExcelUtils_two(exlPath, shtName);
		
		 xl.getRowCount();
		for(int i=1;i< 3;i++)
		{
			System.out.println("ROW  : "+ i);
			for(int j=0;j< 3;j++)
			{
				xl.getCelData(i, j);
			}System.out.println("_______________________________________________________________");
		}

	}

}
