package TESTS;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class GETpostExamples {

	
	
	
	@Test
	public void testPUT()
	{
		
		JSONObject req= new JSONObject();
		req.put("name", "Mita Singh");
		req.put("job", "Prime Deputy Manager");
		System.out.println(req);
		
		baseURI= "https://reqres.in/api";
		
		given().
			header("Content-Type","application/json").
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			body(req.toJSONString()).
		when().
			put("/users/2").
			then().
			statusCode(200).
			log().all();
		
		System.out.println("--------------------------------------------------------------------------------------------------");
	}
	
	
	
	public void testPatch()
	{
		
		JSONObject req= new JSONObject();
		req.put("name", "Mita Mandani");
		req.put("job", "Deputy Commissioner");
		System.out.println(req);
		
		baseURI= "https://reqres.in";
		
		given().
			header("Content-Type","application/json").
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			body(req.toJSONString()).
		when().
			patch("/api/users/2").
			then().
			statusCode(200).
			log().all();
		
		System.out.println("----------------------------------------------------------------------------------------------------------");
	}
	
	
	@Test
	public void testDelete()
	{
	
		baseURI= "https://reqres.in";
		when().
			delete("/api/users/2").
			then().
			statusCode(204).
			log().all();
	}
	@Test
	public void testGet()
	{
		baseURI= "https://reqres.in/api";
		given().
			get("/users?page=2").
		then().
			statusCode(200).
		body("data[4].first_name",equalTo("George")).
		body("data.first_name",hasItems("Lindsay","Rachel"));
		
	}
	
	
	
	@Test
	public void testPost2()
	{
		
		JSONObject req= new JSONObject();
		req.put("name", "Mohan Singh");
		req.put("job", "Prime Minister");
		System.out.println(req);
		
		baseURI= "https://reqres.in/api";
		
		given().
			header("Content-Type","application/json").
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			body(req.toJSONString()).
		when().
			post("/users").
			then().
			statusCode(201).
			log().all();
	}
	
	
	
	@Test
	public void validateSoapXML() throws IOException
	{
	
		File fle= new File("./SoapRequest/Add.xml");
		FileInputStream fis= new FileInputStream(fle);
		String reqBody= IOUtils.toString(fis,"UTF-8");
		baseURI="http://dneonline.com/";
		given().contentType("text/xml").
				accept(ContentType.XML).
				body(reqBody);
	}
	
}
