package JsonToJavaObjects;

public class Properties {
	public String place;
}
