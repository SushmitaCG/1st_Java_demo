package JsonToJavaObjects;

public class Features {
	public Properties properties;

}
