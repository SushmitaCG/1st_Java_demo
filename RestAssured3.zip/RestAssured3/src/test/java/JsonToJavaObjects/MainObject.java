package JsonToJavaObjects;

import java.util.List;

public class MainObject {
	public List<Features> features;
}
